# -*- coding: utf-8 -*-
"""
Simple processing for russian strings
"""
VERSION = '0.4.0dev'

from pytils import dt, numeral, translit, typo, utils
